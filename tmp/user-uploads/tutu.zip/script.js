document.addEventListener('DOMContentLoaded', function () {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('primary-navigation');

  if (navToggle && nav) {
    navToggle.addEventListener('click', function () {
      const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
      navToggle.setAttribute('aria-expanded', String(!isExpanded));
      nav.classList.toggle('is-active');
      document.body.classList.toggle('nav-open');
    });

    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        if (window.innerWidth < 768 && nav.classList.contains('is-active')) {
          nav.classList.remove('is-active');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.classList.remove('nav-open');
        }
      });
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth >= 768) {
        nav.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.classList.remove('nav-open');
      }
    });
  }

  const cookieBanner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');

  if (cookieBanner && acceptBtn && declineBtn) {
    let storedDecision = null;
    try {
      storedDecision = localStorage.getItem('abhCookieConsent');
    } catch (error) {
      storedDecision = null;
    }

    if (!storedDecision) {
      cookieBanner.classList.add('visible');
      cookieBanner.setAttribute('aria-hidden', 'false');
    }

    const handleDecision = function (decision) {
      try {
        localStorage.setItem('abhCookieConsent', decision);
      } catch (error) {
        // Ignore storage errors silently
      }
      cookieBanner.classList.remove('visible');
      cookieBanner.setAttribute('aria-hidden', 'true');
    };

    acceptBtn.addEventListener('click', function () {
      handleDecision('accepted');
    });

    declineBtn.addEventListener('click', function () {
      handleDecision('declined');
    });
  }
});