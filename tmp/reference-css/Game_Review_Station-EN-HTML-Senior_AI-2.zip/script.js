document.addEventListener('DOMContentLoaded', function() {
  
  // --- Mobile Menu ---
  const navToggle = document.querySelector('.nav-toggle');
  const body = document.body;

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      body.classList.toggle('nav-open');
    });
  }

  // Close mobile menu when a link is clicked
  const navLinks = document.querySelectorAll('.nav-links a');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (body.classList.contains('nav-open')) {
        body.classList.remove('nav-open');
      }
    });
  });

  // --- Active Nav Link ---
  const currentPage = window.location.pathname.split("/").pop() || 'index.html';
  const activeLink = document.querySelector(`.nav-links a[href="${currentPage}"]`);
  if (activeLink) {
    activeLink.classList.add('active');
  }

  // --- Hero Gallery Interaction (Example) ---
  const heroSection = document.querySelector('.hero');
  const galleryThumbs = document.querySelectorAll('.hero-gallery__thumb');

  if (heroSection && galleryThumbs.length > 0) {
    galleryThumbs.forEach(thumb => {
      thumb.addEventListener('click', function() {
        const newBg = this.getAttribute('data-bg');
        heroSection.style.backgroundImage = `url('${newBg}')`;

        galleryThumbs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
      });
    });
  }

  // --- FAQ Accordion ---
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
      item.classList.toggle('open');
    });
  });

  // --- Cookie Banner ---
  const cookieConsent = localStorage.getItem('cookieConsent');
  const banner = document.getElementById('cookie-banner');
  if (!cookieConsent && banner) {
    banner.style.display = 'flex';
  }
});

function acceptCookies() {
  localStorage.setItem('cookieConsent', 'accepted');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

function declineCookies() {
  localStorage.setItem('cookieConsent', 'declined');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

function handleFormSubmit(event) {
  event.preventDefault();
  // In a real application, you would send the form data to a server here.
  // For this static example, we just redirect to the thank-you page.
  window.location.href = 'thank-you.html';
}