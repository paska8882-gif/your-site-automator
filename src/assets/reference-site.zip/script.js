document.addEventListener('DOMContentLoaded', function() {
  // Mobile Menu
  const menuToggle = document.getElementById('mobile-menu-toggle');
  const navLinks = document.querySelector('.nav-links');

  if (menuToggle && navLinks) {
    menuToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
      menuToggle.classList.toggle('active');
    });

    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('active');
            menuToggle.classList.remove('active');
        });
    });
  }

  // Active Nav Link
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  const navAnchors = document.querySelectorAll('.nav-links a');
  navAnchors.forEach(link => {
    if (link.getAttribute('href') === currentPage) {
      link.classList.add('active');
    }
  });

  // Cookie Consent
  const cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    const cookieConsent = localStorage.getItem('cookieConsent');
    if (!cookieConsent) {
      cookieBanner.style.display = 'flex';
    }
  }

});

function acceptCookies() {
  localStorage.setItem('cookieConsent', 'accepted');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

function declineCookies() {
  localStorage.setItem('cookieConsent', 'declined');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

function handleFormSubmit(event) {
  event.preventDefault();
  // Here you would normally send data to a server.
  // For this static site, we'll just redirect to the thank-you page.
  window.location.href = 'thank-you.html';
}