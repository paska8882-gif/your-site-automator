document.addEventListener('DOMContentLoaded', () => {
    const navToggle = document.querySelector('.nav-toggle');
    const siteNav = document.querySelector('.site-nav');
    if (navToggle && siteNav) {
        navToggle.addEventListener('click', () => {
            siteNav.classList.toggle('open');
            navToggle.classList.toggle('open');
        });
        siteNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                if (siteNav.classList.contains('open')) {
                    siteNav.classList.remove('open');
                    navToggle.classList.remove('open');
                }
            });
        });
    }

    const cookieBanner = document.getElementById('cookie-banner');
    const storageKey = 'norethalbq_cookie_choice';
    if (cookieBanner) {
        let storedChoice = null;
        try {
            storedChoice = localStorage.getItem(storageKey);
        } catch (e) {
            storedChoice = null;
        }
        if (storedChoice) {
            cookieBanner.classList.add('hidden');
        }
        cookieBanner.querySelectorAll('[data-cookie-choice]').forEach(btn => {
            btn.addEventListener('click', event => {
                event.preventDefault();
                const choice = btn.getAttribute('data-cookie-choice');
                try {
                    localStorage.setItem(storageKey, choice);
                } catch (e) {
                    /* storage might be unavailable; ignore */
                }
                cookieBanner.classList.add('hidden');
            });
        });
    }
});