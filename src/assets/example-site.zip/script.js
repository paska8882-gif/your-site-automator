document.addEventListener('DOMContentLoaded', function() {
  
  // Mobile Menu Toggle
  const hamburger = document.querySelector('.hamburger-menu');
  const navLinks = document.querySelector('.nav-links');

  if (hamburger && navLinks) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active');
      navLinks.classList.toggle('active');
    });

    navLinks.addEventListener('click', (e) => {
        if (e.target.tagName === 'A') {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        }
    });
  }

  // Cookie Consent Banner
  const banner = document.getElementById('cookie-banner');
  const acceptBtn = document.getElementById('cookie-accept-btn');
  const declineBtn = document.getElementById('cookie-decline-btn');
  const cookieConsent = localStorage.getItem('cookieConsent');

  if (!cookieConsent && banner) {
    banner.style.display = 'flex';
  }

  if (acceptBtn) {
    acceptBtn.addEventListener('click', acceptCookies);
  }

  if (declineBtn) {
    declineBtn.addEventListener('click', declineCookies);
  }

  // Fade-in animations on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
      }
    });
  }, {
    threshold: 0.1
  });

  document.querySelectorAll('.fade-in').forEach(element => {
    observer.observe(element);
  });
  
  // Active nav link
  const currentPath = window.location.pathname.split("/").pop() || 'index.html';
  const navAnchors = document.querySelectorAll('.nav-links a');
  navAnchors.forEach(link => {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('active');
    }
  });

});

function acceptCookies() {
  localStorage.setItem('cookieConsent', 'accepted');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

function declineCookies() {
  localStorage.setItem('cookieConsent', 'declined');
  const banner = document.getElementById('cookie-banner');
  if(banner) banner.style.display = 'none';
}

// Contact Form Submission (for static site)
const contactForm = document.getElementById('contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        // Here you would typically send data to a server.
        // For a static site, we redirect to a 'thank you' page.
        window.location.href = 'thank-you.html';
    });
}